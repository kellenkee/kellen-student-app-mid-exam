package com.example.student_mis.dao;

import com.example.student_mis.model.CourseDefinition;
import com.example.student_mis.model.Semester;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.ArrayList;
import java.util.List;

public class CourseDefinitionDao {
    Session session = HibernateUtil.getSessionFactory().openSession();
    public boolean addCourseDefinition(CourseDefinition courseDefinition){
        Transaction tx = session.beginTransaction();
        session.merge(courseDefinition);
        tx.commit();
        session.close();
        return true;
    }
    public List<CourseDefinition> findAll() {
        Session session = null;
        List<CourseDefinition> result = new ArrayList<>();
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            result = session.createQuery("from CourseDefinition ").list();
        } catch (HibernateException ex) {
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return result;

    }
    public boolean deleteDefinition(CourseDefinition definition){
        Transaction tx = session.beginTransaction();
        session.remove(definition);
        tx.commit();
        session.close();
        return true;
    }
    public CourseDefinition findUnitByName(String name) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            String hql = "FROM CourseDefinition WHERE cName = :definition";
            Query<CourseDefinition> query = session.createQuery(hql, CourseDefinition.class);
            query.setParameter("definition", name);

            return query.uniqueResult();
        }
    }
}
