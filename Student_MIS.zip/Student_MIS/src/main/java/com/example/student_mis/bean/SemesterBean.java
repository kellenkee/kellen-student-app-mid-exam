package com.example.student_mis.bean;

import java.time.LocalDate;
import java.util.UUID;

public class SemesterBean {
    private UUID Id;
    private String sName;
    private LocalDate startDate;
    private LocalDate endDate;
    private String errorMessage;
    private String successMessage;

    public SemesterBean() {
    }

    public SemesterBean(UUID id, String sName, LocalDate startDate, LocalDate endDate, String errorMessage, String successMessage) {
        Id = id;
        this.sName = sName;
        this.startDate = startDate;
        this.endDate = endDate;
        this.errorMessage = errorMessage;
        this.successMessage = successMessage;
    }

    public UUID getId() {
        return Id;
    }

    public void setId(UUID id) {
        Id = id;
    }

    public String getsName() {
        return sName;
    }

    public void setsName(String sName) {
        this.sName = sName;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getSuccessMessage() {
        return successMessage;
    }

    public void setSuccessMessage(String successMessage) {
        this.successMessage = successMessage;
    }
}
