package com.example.student_mis.model;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.Locale;
import java.util.UUID;

@Entity
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer regNo;
    private String fullname;
    private LocalDate dob;

    public Student() {
    }

    public Student( Integer regNo, String fullname, LocalDate dob) {

        this.regNo = regNo;
        this.fullname = fullname;
        this.dob = dob;
    }


    public long getRegNo() {
        return regNo;
    }

    public void setRegNo(Integer regNo) {
        this.regNo = regNo;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }
}
