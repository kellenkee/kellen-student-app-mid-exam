package com.example.student_mis.dao;

import com.example.student_mis.model.Course;
import com.example.student_mis.model.StudentRegistration;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class StudentRegistrationDao {
    Session session = HibernateUtil.getSessionFactory().openSession();

    public boolean addStudentRegistration(StudentRegistration studentRegistration){
        Transaction tx = session.beginTransaction();
        session.merge(studentRegistration);
        tx.commit();
        session.close();
        return true;
    }
    public List<StudentRegistration> findAll() {
        Session session = null;
        List<StudentRegistration> result = new ArrayList<>();
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            result = session.createQuery("from StudentRegistration ").list();
        } catch (HibernateException ex) {
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return result;

    }
    public StudentRegistration studentRegistrationId(UUID id){
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            String hql = "FROM StudentRegistration WHERE id = :id";
            Query<StudentRegistration> query = session.createQuery(hql, StudentRegistration.class);
            query.setParameter("id", id);

            return query.uniqueResult();
        }
    }

}
