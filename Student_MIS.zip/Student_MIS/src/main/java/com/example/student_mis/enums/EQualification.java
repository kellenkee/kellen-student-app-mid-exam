package com.example.student_mis.enums;

public enum EQualification {
    MASTER,
    PHD,
    PROFESSOR;
}
