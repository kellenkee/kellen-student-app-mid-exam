package com.example.student_mis.enums;

public enum EAcademicUnit {
    PROGRAMME,
    FACULTY,
    DEPARTMENT;
}
