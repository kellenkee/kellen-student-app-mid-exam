package com.example.student_mis.Service.implementation;

import com.example.student_mis.Service.interfaces.StudentService;
import com.example.student_mis.dao.StudentDao;
import com.example.student_mis.model.Student;

import java.rmi.RemoteException;
import java.util.List;

public class StudentServiceImpl implements StudentService {

    StudentDao studentDao = new StudentDao();
    @Override
    public boolean addStudent(Student student) {
        return studentDao.addStudent(student);
    }

    @Override
    public List<Student> getStudent() throws RemoteException {
        return studentDao.findAll();
    }

    @Override
    public Student findStudentById(Integer id) {
        return studentDao.findStudentByRegNo(id);
    }
}
