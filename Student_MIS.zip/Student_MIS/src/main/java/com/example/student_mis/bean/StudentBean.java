package com.example.student_mis.bean;

import java.time.LocalDate;

public class StudentBean {
    private Integer regNo;
    private String fullname;
    private LocalDate dob;
    private String errorMessage;
    private String successMessage;

    public StudentBean() {
    }

    public StudentBean(Integer regNo, String fullname, LocalDate dob, String errorMessage, String successMessage) {
        this.regNo = regNo;
        this.fullname = fullname;
        this.dob = dob;
        this.errorMessage = errorMessage;
        this.successMessage = successMessage;
    }

    public Integer getRegNo() {
        return regNo;
    }

    public void setRegNo(Integer regNo) {
        this.regNo = regNo;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getSuccessMessage() {
        return successMessage;
    }

    public void setSuccessMessage(String successMessage) {
        this.successMessage = successMessage;
    }
}