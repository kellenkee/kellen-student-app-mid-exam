package com.example.student_mis.Service.implementation;

import com.example.student_mis.Service.interfaces.AcademicService;
import com.example.student_mis.dao.AcademicUnitDao;
import com.example.student_mis.model.AcademicUnit;

import java.rmi.RemoteException;
import java.util.List;

public class AcademicServiceImpl  extends RemoteException implements AcademicService {
    AcademicUnitDao academicUnitDao = new AcademicUnitDao();
    @Override
    public boolean insertUnit(AcademicUnit unit) {
        return academicUnitDao.insertUnit(unit);
    }

    @Override
    public List<AcademicUnit> unitList() {
        return academicUnitDao.unitList();
    }

    @Override
    public boolean deleteUnit(AcademicUnit unit) {
        return academicUnitDao.deleteUnit(unit);
    }

    @Override
    public AcademicUnit findUnitByName(String name) {
        return academicUnitDao.findUnitByName(name);
    }

    @Override
    public AcademicUnit findUnitById(String id) {
        return academicUnitDao.findUnitById(id);
    }

}
