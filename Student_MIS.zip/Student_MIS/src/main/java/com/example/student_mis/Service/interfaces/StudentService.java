package com.example.student_mis.Service.interfaces;

import com.example.student_mis.model.Student;

import java.rmi.RemoteException;
import java.util.List;

public interface StudentService {

    public boolean addStudent(Student student);

    public List<Student> getStudent() throws RemoteException;
    public Student findStudentById(Integer id);
}
