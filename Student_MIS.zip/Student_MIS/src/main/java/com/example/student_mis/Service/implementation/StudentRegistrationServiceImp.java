package com.example.student_mis.Service.implementation;

import com.example.student_mis.Service.interfaces.StudentRegistrationService;
import com.example.student_mis.dao.StudentRegistrationDao;
import com.example.student_mis.model.Course;
import com.example.student_mis.model.StudentRegistration;

import java.rmi.RemoteException;
import java.util.List;
import java.util.UUID;

public class StudentRegistrationServiceImp implements StudentRegistrationService {
    StudentRegistrationDao studentRegistrationDao = new StudentRegistrationDao();
    @Override
    public boolean addStudentRegistration(StudentRegistration studentRegistration) {
        return studentRegistrationDao.addStudentRegistration(studentRegistration);
    }

    @Override
    public List<StudentRegistration> getStudentRegistration() throws RemoteException {
        return studentRegistrationDao.findAll();
    }

    @Override
    public StudentRegistration studRegistrationById(UUID id) {
        return studentRegistrationDao.studentRegistrationId(id);
    }
}
