package com.example.student_mis.Service.interfaces;

import com.example.student_mis.model.AcademicUnit;

import java.util.List;

public interface AcademicService {
    public boolean insertUnit(AcademicUnit unit);
    public List<AcademicUnit> unitList();
    public boolean deleteUnit(AcademicUnit unit);
    public AcademicUnit findUnitByName(String name);
    public AcademicUnit findUnitById(String id);
}
