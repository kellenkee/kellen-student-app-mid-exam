package com.example.student_mis.Service.interfaces;

import com.example.student_mis.model.StudentCourse;

import java.util.List;

public interface StudentCourseService {
    public boolean insertStudentCourse(StudentCourse course);
    public List<StudentCourse> studentCourseList();
    public boolean deleteStudentCourse(StudentCourse course);
}
