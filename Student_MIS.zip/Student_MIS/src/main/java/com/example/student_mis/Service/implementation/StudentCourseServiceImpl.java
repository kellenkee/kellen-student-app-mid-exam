package com.example.student_mis.Service.implementation;

import com.example.student_mis.Service.interfaces.StudentCourseService;
import com.example.student_mis.dao.StudentCourseDao;
import com.example.student_mis.model.StudentCourse;

import java.util.List;

public class StudentCourseServiceImpl implements StudentCourseService {
    StudentCourseDao studentCourseDao = new StudentCourseDao();
    @Override
    public boolean insertStudentCourse(StudentCourse course) {
        return studentCourseDao.insertStudentCourse(course);
    }

    @Override
    public List<StudentCourse> studentCourseList() {
        return studentCourseDao.studentCourseList();
    }

    @Override
    public boolean deleteStudentCourse(StudentCourse course) {
        return studentCourseDao.deleteStudentCourse(course);
    }
}
