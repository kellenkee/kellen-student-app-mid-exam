package com.example.student_mis.Service.interfaces;

import com.example.student_mis.model.CourseDefinition;

import java.rmi.RemoteException;
import java.util.List;

public interface CourseDefService {
    public boolean addCourseDefinition(CourseDefinition courseDefinition);
    public List<CourseDefinition> getCourseDef() throws RemoteException;
    public boolean deleteDefinition(CourseDefinition definition);
    public CourseDefinition findUnitByName(String name);
}
