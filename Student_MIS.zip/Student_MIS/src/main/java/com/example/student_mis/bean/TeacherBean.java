package com.example.student_mis.bean;

import com.example.student_mis.enums.EQualification;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;

import java.util.UUID;

public class TeacherBean {
    private UUID Id;
    private String code;
    private String tName;
    private EQualification qualification;

    public TeacherBean() {
    }

    public TeacherBean(UUID id, String code, String tName, EQualification qualification) {
        Id = id;
        this.code = code;
        this.tName = tName;
        this.qualification = qualification;
    }

    public UUID getId() {
        return Id;
    }

    public void setId(UUID id) {
        Id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String gettName() {
        return tName;
    }

    public void settName(String tName) {
        this.tName = tName;
    }

    public EQualification getQualification() {
        return qualification;
    }

    public void setQualification(EQualification qualification) {
        this.qualification = qualification;
    }
}
