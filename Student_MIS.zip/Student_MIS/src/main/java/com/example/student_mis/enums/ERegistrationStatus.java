package com.example.student_mis.enums;

public enum ERegistrationStatus {
    PENDING,
    ADMITTED,
    REJECTED;
}
