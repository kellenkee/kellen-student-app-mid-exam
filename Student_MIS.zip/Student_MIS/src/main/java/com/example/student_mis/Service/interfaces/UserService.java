package com.example.student_mis.Service.interfaces;

public interface UserService {
    public String loginUser(String email, String password);
}
