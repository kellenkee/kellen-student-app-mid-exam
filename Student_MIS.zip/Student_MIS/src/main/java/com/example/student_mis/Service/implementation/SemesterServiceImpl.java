package com.example.student_mis.Service.implementation;

import com.example.student_mis.Service.interfaces.SemesterInteface;
import com.example.student_mis.dao.SemesterDao;
import com.example.student_mis.model.Semester;

import java.rmi.RemoteException;
import java.util.List;

public class SemesterServiceImpl extends RemoteException implements SemesterInteface {
    public SemesterServiceImpl(){
        super();
    }
    SemesterDao semesterDao = new SemesterDao();

    @Override
    public boolean addSemester(Semester semester) {
        return semesterDao.addSemester(semester);
    }

    @Override
    public List<Semester> getSemesters() throws RemoteException {
        return semesterDao.findAll();
    }

    @Override
    public Semester findSemesterByName(String name) {
        return semesterDao.findSemesterByName(name);
    }
}
