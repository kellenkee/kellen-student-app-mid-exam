package com.example.student_mis.bean;

import java.security.SecureRandom;
import java.util.UUID;

public class CourseDefinitionBean {
    private UUID Id;
    private String Code;
    private String cName;
    private String description;
    private String errorMessage;
    private String successMessage;

    public CourseDefinitionBean() {
    }

    public CourseDefinitionBean(UUID id, String code, String cName, String description, String errorMessage, String successMessage) {
        Id = id;
        Code = code;
        this.cName = cName;
        this.description = description;
        this.errorMessage = errorMessage;
        this.successMessage = successMessage;
    }

    public UUID getId() {
        return Id;
    }

    public void setId(UUID id) {
        Id = id;
    }

    public String getCode() {
        return Code;
    }

    public void setCode(String code) {
        Code = code;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getSuccessMessage() {
        return successMessage;
    }

    public void setSuccessMessage(String successMessage) {
        this.successMessage = successMessage;
    }
}
