package com.example.student_mis.dao;

import com.example.student_mis.model.CourseDefinition;
import com.example.student_mis.model.Student;
import com.example.student_mis.model.Teacher;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import jakarta.persistence.criteria.*;
import org.hibernate.query.Query;

import java.util.ArrayList;
import java.util.List;

public class StudentDao {
    Session session = HibernateUtil.getSessionFactory().openSession();

    public boolean addStudent(Student courseDefinition) {
        Transaction tx = session.beginTransaction();
        session.merge(courseDefinition);
        tx.commit();
        session.close();
        return true;
    }

    public Student findStudentByRegNo(Integer regNo){
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            String hql = "FROM Student WHERE regNo = :regNo";
            Query<Student> query = session.createQuery(hql, Student.class);
            query.setParameter("regNo", regNo);
            return query.uniqueResult();
        }
    }
    public List<Student> findAll() {
        Session session = null;
        List<Student> result = new ArrayList<>();
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            result = session.createQuery("from Student ").list();
        } catch (HibernateException ex) {
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return result;
    }
        public boolean updateStudent(Student student) {
            boolean result = false;
            Session session = HibernateUtil.getSessionFactory().openSession();
            Transaction tx = session.beginTransaction();
            session.update(student);
            tx.commit();
            session.close();
            result = Boolean.TRUE;
            return result;
        }


        public void deleteStudent(Student student) {
            Session session = HibernateUtil.getSessionFactory().openSession();
            Transaction tx = session.beginTransaction();
            session.delete(student);
            tx.commit();
            session.close();
        }

    }
