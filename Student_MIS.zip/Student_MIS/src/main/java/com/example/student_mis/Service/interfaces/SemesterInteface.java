package com.example.student_mis.Service.interfaces;

import com.example.student_mis.model.Semester;

import java.rmi.RemoteException;
import java.util.List;

public interface SemesterInteface {
    public boolean addSemester(Semester semester);
    public List<Semester> getSemesters() throws RemoteException;
    public Semester findSemesterByName(String name);
}
