import com.example.student_mis.Service.implementation.CourseServiceImpl;
import com.example.student_mis.Service.implementation.StudentServiceImpl;
import com.example.student_mis.Service.interfaces.CourseService;
import com.example.student_mis.Service.interfaces.StudentService;
import com.example.student_mis.model.Course;
import com.example.student_mis.model.Student;
import org.junit.jupiter.api.Test;


import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class testInsert {
    @Test
    public void testSemester(){
        Course course = new Course();
        course.setId(UUID.randomUUID());
        CourseService service = new CourseServiceImpl();
        service.addCourse(course);
    }
    @Test
    public void testFindStudent(Integer id){
        Student student = new Student();
        StudentService studentService = new StudentServiceImpl();
        studentService.findStudentById(1);
        assertNotNull(student);
    }
}
